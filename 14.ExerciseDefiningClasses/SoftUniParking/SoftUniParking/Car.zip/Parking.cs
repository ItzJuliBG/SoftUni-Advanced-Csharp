﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SoftUniParking
{
    class Parking
    {
        private List<Car> cars;
        private int capacity;
        private int count;

        public Parking(int capacity)
        {
            count = 0;
            cars = new List<Car>();
            this.Capacity = capacity; //may be Capacity
        }

        public int Count { get => count; set => count = value; }
        public List<Car> Cars { get => cars; set => cars = value; }
        public int Capacity { get => capacity; set => capacity = value; }

        public void AddCar(Car car)
        {
            bool isExisted = cars.Any(c => c.RegistrationNumber == car.RegistrationNumber);
            if (isExisted)
            {
                Console.WriteLine("Car with that registration number, already exists!");
            }
            else if (cars.Count >= capacity)
            {
                Console.WriteLine("Parking is full!");
            }
            else
            {
                Console.WriteLine($"Successfully added new car {car.Make} {car.RegistrationNumber}");
                count++;
                cars.Add(car);
            }
        }
    }
}
