﻿namespace FishingNet
{
    public class Net
    {

    }
}
