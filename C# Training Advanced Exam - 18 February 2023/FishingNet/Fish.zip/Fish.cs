﻿namespace FishingNet
{
    public class Fish
    {

    }
}
